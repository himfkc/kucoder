<?php
declare(strict_types=1);

namespace plugin\member\app\api\controller;

use plugin\kucoder\app\kucoder\controller\ApiBase;
use plugin\kucoder\app\kucoder\lib\Captcha;
use plugin\kucoder\app\kucoder\service\MenuService;
use Psr\SimpleCache\InvalidArgumentException;
use support\exception\BusinessException;
use support\Request;
use support\Response;
use think\db\exception\DataNotFoundException;
use think\db\exception\DbException;
use think\db\exception\ModelNotFoundException;
use Throwable;

class LoginController extends ApiBase
{
    protected array $noNeedLogin = ['login', 'changeCaptcha'];
    protected array $noNeedRight = ['getRouters', 'logout'];
    private static array $showFields = ['token','nickname','avatar','site_set'];


    /**
     * 登录验证码
     * @return Response
     * @throws InvalidArgumentException
     */
    public function changeCaptcha(): Response
    {
        return $this->ok('', ['captcha' => Captcha::create()]);
    }

    /**
     * @throws Throwable
     * @throws DataNotFoundException
     * @throws BusinessException
     * @throws ModelNotFoundException
     * @throws DbException
     * @throws InvalidArgumentException
     */
    public function login(Request $request): Response
    {
        //判断是否登录
        /*if ($this->auth->isLogin()) {
            return $this->error('你已经登录了');
        }*/
        if (!$request->isPost()) {
            return $this->error('请求方式错误');
        }
        //验证器
        $this->validate();
        //验证码
        $uuid = $request->post('uuid');
        $code = $request->post('code');
        if (!Captcha::check($uuid, $code)) {
            return $this->error('验证码错误');
        }
        //登录
        $userModelClass = "\\plugin\\member\\app\\admin\\model\\Member";
        if (!$userInfo = $this->auth->login(null,$userModelClass)) {
            return $this->error('登录失败');
        }
        $userInfo = reserve_array_key($userInfo,self::$showFields);
        $userInfo['site_set'] = [
            'logo' => '/favicon.ico',
            'site_name' => 'Kucoder快速开发框架',
            'upload_path' => config('plugin.kucoder.app.upload_path'),
            'sys_url' => config('plugin.kucoder.app.sys_url'),
            'sys_file_url' => config('plugin.kucoder.app.sys_file_url') ?: config('plugin.kucoder.app.sys_url'),
        ];
        return $this->ok('登录成功', $userInfo);
    }

    /**
     * 退出登录
     * @return Response
     * @throws InvalidArgumentException
     */
    public function logout(): Response
    {
        $this->auth->logout();
        return $this->ok('退出成功');
    }

    public function getRouters(): Response
    {
        $userId = $this->auth->getId();
        $menus = $this->auth->getUserMenus($userId);
        $btns = $this->auth->getUserBtns($userId);

        $roleMenus = array_map(function ($item) {
            return [
                'id' => $item['id'],
                'pid' => $item['pid'],
                'title' => $item['title'],
            ];
        }, $menus);
        $roleMenus = get_recursion_data($roleMenus);

        return $this->ok('', [
            'routes' => MenuService::menusToRoutes($menus),
            'btns' => $btns,
            'roleMenus' => $roleMenus,
        ]);
    }
}