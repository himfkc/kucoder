<?php
return [
    'files' => [
        base_path() . '/plugin/member/app/functions.php',
    ]
];