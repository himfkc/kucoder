<?php
declare(strict_types=1);

namespace plugin\member\app\admin\validate;

use think\Validate;

class MemberRole extends Validate
{
    protected $rule = [
        'role_name|会员角色名称' => 'require',
        'rules|会员角色权限' => 'require',
    ];
}