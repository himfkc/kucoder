<?php
declare(strict_types=1);

namespace plugin\member\app\admin\model;

use support\think\Model;
use think\model\concern\SoftDelete;

class Base extends Model
{
    // 软删除
    use SoftDelete;
    protected $deleteTime = 'delete_time';
    protected $defaultSoftDelete = NULL;

    // 自动写入时间戳 主项目think-orm配置文件已配置 这里使用主项目的配置
    // protected $autoWriteTimestamp = true;
}