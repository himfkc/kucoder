<?php
declare(strict_types=1);

namespace plugin\member\app\admin\model;

class Member extends Base
{
    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $pk = 'm_id';

    public function role(): \think\model\relation\BelongsTo
    {
        return $this->belongsTo(MemberRole::class,'role_ids','role_id');
    }
}