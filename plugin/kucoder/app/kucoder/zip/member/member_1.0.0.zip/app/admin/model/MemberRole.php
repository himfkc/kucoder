<?php
declare(strict_types=1);

namespace plugin\member\app\admin\model;

class MemberRole extends Base
{
    /**
     * The primary key associated with the table.
     * @var string
     */
    protected $pk = 'role_id';

    /**
     * @param string $value
     * @return string[]
     */
    public function getRulesAttr(string $value): array
    {
        return $value ? explode(',', $value) :[];
    }

    /**
     * @param array $value
     * @return string
     */
    public function setRulesAttr(array $value):string
    {
        return $value ? implode(',', $value) : '';
    }
}