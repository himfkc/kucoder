<?php
declare(strict_types=1);

namespace plugin\member\app\admin\validate;

use think\Validate;

class Member extends Validate
{
    protected $rule = [
        'username|会员名' => 'require|alphaNum|min:2|unique:member,username',
        'password|密码' => 'require|alphaNum|min:6',
        'role_ids|角色' => 'require',
        'email|邮箱' => 'checkEmail|unique:member,email',
        'mobile|手机号' => 'checkMobile|unique:member,mobile',
    ];

    protected $scene = [
        'add' => ['username', 'password', 'role_ids','email','mobile'],
        'edit' => ['role_ids','email','mobile']
    ];

    protected function checkEmail($value,$rule,$data,$field,$fieldName): bool|string
    {
        if($value && !filter_var($value,FILTER_VALIDATE_EMAIL)){
            return '邮箱格式不正确';
        }
        return true;
    }

    protected function checkMobile($value,$rule,$data,$field,$fieldName):bool|string
    {
        if($value && !preg_match('/^1[3-9]\d{9}$/',$value)){
            return '手机号码格式不正确';
        }
        return true;
    }
}