<?php
return array (
  0 => 
  array (
    'title' => '会员管理',
    'icon' => 'user',
    'type' => 'dir',
    'plugin' => 'member',
    'path' => '',
    'component' => '',
    'name' => '',
    'query' => '',
    'link_url' => '',
    'link_target' => NULL,
    'keepalive' => 0,
    'sort' => 999,
    'show' => 1,
    'remark' => '',
    'children' => 
    array (
      0 => 
      array (
        'title' => '会员列表',
        'icon' => '#',
        'type' => 'menu',
        'plugin' => 'member',
        'path' => 'member',
        'component' => 'member',
        'name' => 'MemberMember',
        'query' => '',
        'link_url' => '',
        'link_target' => NULL,
        'keepalive' => 1,
        'sort' => 999,
        'show' => 1,
        'remark' => '',
        'children' => 
        array (
          0 => 
          array (
            'title' => '查询',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/index',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          1 => 
          array (
            'title' => '新增',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/add',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          2 => 
          array (
            'title' => '修改',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/edit',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          3 => 
          array (
            'title' => '删除',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/delete',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          4 => 
          array (
            'title' => '回收站',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/recycle',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          5 => 
          array (
            'title' => '重置密码',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'member/resetPwd',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
        ),
      ),
      1 => 
      array (
        'title' => '会员角色',
        'icon' => '#',
        'type' => 'menu',
        'plugin' => 'member',
        'path' => 'memberRole',
        'component' => 'memberRole',
        'name' => 'MemberMemberRole',
        'query' => '',
        'link_url' => '',
        'link_target' => NULL,
        'keepalive' => 1,
        'sort' => 999,
        'show' => 1,
        'remark' => '',
        'children' => 
        array (
          0 => 
          array (
            'title' => '查询',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'memberRole/index',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          1 => 
          array (
            'title' => '新增',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'memberRole/add',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          2 => 
          array (
            'title' => '修改',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'memberRole/edit',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          3 => 
          array (
            'title' => '删除',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'memberRole/delete',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
          4 => 
          array (
            'title' => '回收站',
            'icon' => '#',
            'type' => 'button',
            'plugin' => 'member',
            'path' => 'memberRole/recycle',
            'component' => '',
            'name' => '',
            'query' => '',
            'link_url' => '#',
            'link_target' => NULL,
            'keepalive' => 0,
            'sort' => 0,
            'show' => 0,
            'remark' => '',
            'children' => 
            array (
            ),
          ),
        ),
      ),
    ),
  ),
);