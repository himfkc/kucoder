<?php

use support\Request;

return [
    'debug' => true,
    'controller_suffix' => 'Controller',
    'controller_reuse' => false,

    /**
     * 以下是插件开发配置项 kucoder的每个插件都需要配置
     */
    //插件标识 全网唯一
    'name' => 'member',
    //插件名称
    'title' => '会员管理',
    //插件版本号
    'version' => '1.0.0',
    //插件依赖的最低kucoder版本
    'kucoder_version' => '1.0.0',
    //插件类型 0=辅助开发插件,1=完整独立系统,2=完整sass系统,3=物联网应用
    'type' => 0,
    //插件是否收费 付费类型:0=免费,1=收费
    'fee_type' => 0,
    //普通授权收费价格 如99/99.9 普通授权的购买者仅能用于自营项目 更新维护期限为一年
    'common_price' => 0,
    //高级授权收费价格 如999/999.9 高级授权的购买者能用于自营及外包项目 更新维护期限为10年
    'advance_price' => 0,
    //插件作者
    'author' => 'kucoder',
    //插件作者ID 即kucoder的会员ID 登录kucoder后查看
    'author_id' => 1,
    //插件主页地址
    'homepage' => '',
    //插件文档地址
    'doc_url' => '',
    //是否创建插件目录 插件目录:0=不创建,1=创建
    'has_dir' => 1,
    //插件是否含有数据表 0=不含,1=包含
    'has_db' => 1,
    //插件是否含有vue模板 0=不含,1=包含
    'has_view' => 1,

    //插件admin访问路径前缀 用来匹配用户访问权限 不建议修改 否则要修改默认路由规则 以适配admin访问路径 如无admin应用 则填写'/app/插件名/'
    'admin_base_dir' => '/app/member/admin/',
    //插件api访问路径前缀  用来匹配用户访问权限 不建议修改 否则要修改默认路由规则 以适配api访问路径 如无api应用 则填写'/app/插件名/'
    'api_base_dir' => '/app/member/api/',
];
