<template>
    <div class="app-container">
        <el-row :gutter="20">
            <splitpanes :horizontal="appStore.device === 'mobile'" class="default-theme">
                <!--会员数据-->
                <pane size="100">
                    <el-col>
                        <!-- 顶部搜索 -->
                        <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch">
                            <el-form-item label="会员名" prop="username">
                                <el-input v-model="queryParams.username" placeholder="请输入会员名" clearable
                                    @keyup.enter="handleQuery" size="small" />
                            </el-form-item>
                            <el-form-item label="手机" prop="mobile">
                                <el-input v-model="queryParams.mobile" placeholder="请输入手机号码" clearable
                                    @keyup.enter="handleQuery" size="small" />
                            </el-form-item>
                            <el-form-item label="会员角色" prop="role_ids">
                                <el-select v-model="queryParams.role_ids" placeholder="请选择" style="width: 120px"
                                    size="small" clearable>
                                    <el-option v-for="(value, key) in roleObj" :key="key" :label="value"
                                        :value="Number(key)"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="开发者" prop="is_developer">
                                <el-select v-model="queryParams.is_developer" placeholder="是否开发者" clearable
                                    style="width: 120px" size="small">
                                    <el-option v-for="dict in enumFieldData.is_developer" :key="dict.value"
                                        :label="dict.label" :value="dict.value" />
                                </el-select>
                            </el-form-item>
                            <el-form-item label="状态" prop="status">
                                <el-select v-model="queryParams.status" placeholder="会员状态" clearable
                                    style="width: 120px" size="small">
                                    <el-option v-for="dict in enumFieldData.status" :key="dict.value"
                                        :label="dict.label" :value="dict.value" />
                                </el-select>
                            </el-form-item>
                            <el-form-item label="创建时间" style="width: 250px">
                                <el-date-picker v-model="dateRange" value-format="YYYY-MM-DD" type="daterange"
                                    range-separator="-" start-placeholder="开始日期" end-placeholder="结束日期"
                                    size="small"></el-date-picker>
                            </el-form-item>
                            <el-form-item>
                                <!-- <el-button size="small" type="primary" icon="Search" @click="handleQuery">搜索</el-button>
                  <el-button size="small" icon="Refresh" @click="resetQuery">重置</el-button> -->
                                <el-button type="primary" @click="handleQuery" size="small">
                                    <icon-ep-search class="icon" />搜索</el-button>
                                <el-button @click="resetQuery" size="small">
                                    <icon-ep-refresh class="icon" />重置</el-button>
                            </el-form-item>
                        </el-form>
                        <!-- 顶部按钮组 -->
                        <el-row :gutter="10" class="mb8">
                            <el-col :span="1.5">
                                <el-tooltip effect="dark" content="刷新" placement="top">
                                    <el-button size="small" type="info" circle plain @click="refresh">
                                        <icon-ep-refresh class=" w-4 " />
                                    </el-button>
                                </el-tooltip>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button type="primary" size="small" @click="handleAdd"
                                    v-hasPermi="['member:add']"><icon-ep-plus class="icon" />新增</el-button>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button type="success" size="small" :disabled="single" @click="handleUpdate"
                                    v-hasPermi="['member:edit']"><icon-ep-edit class="icon" />修改</el-button>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button type="danger" size="small" :disabled="multiple" @click="handleDelete"
                                    v-hasPermi="['member:delete']"><icon-ep-delete class="icon" />删除</el-button>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button size="small" type="warning" @click="handleRecycle"
                                    v-hasPermi="['member:recycle']">
                                    <icon-ep-delete class="icon" />回收站</el-button>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button type="info" size="small" @click="handleImport"
                                    v-hasPermi="['member:import']"><icon-ep-upload class="icon" />导入</el-button>
                            </el-col>
                            <el-col :span="1.5">
                                <el-button type="warning" size="small" @click="handleExport"
                                    v-hasPermi="['member:export']"><icon-ep-download class="icon" />导出</el-button>
                            </el-col>
                            <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"
                                :columns="columns"></right-toolbar>
                        </el-row>
                        <!-- 表格 -->
                        <el-table border v-loading="loading" :data="userList" @selection-change="handleSelectionChange">
                            <el-table-column type="selection" width="50" align="center" />
                            <el-table-column label="会员ID" align="center" key="m_id" prop="m_id"
                                v-if="columns[0].visible" />
                            <el-table-column label="会员名" align="center" key="username" prop="username"
                                v-if="columns[1].visible" :show-overflow-tooltip="true" />
                            <el-table-column label="昵称" align="center" key="nickname" prop="nickname"
                                v-if="columns[2].visible" :show-overflow-tooltip="true" />
                            <el-table-column label="角色" align="center" key="role_ids" prop="role_ids"
                                v-if="columns[3].visible" :show-overflow-tooltip="true">
                                <template #default="scope">
                                    <el-tag size="small" :type="roleObjTag[scope.row.role_ids].tag" class="mr5">{{
                                        roleObj[scope.row.role_ids] }}</el-tag>
                                    <!-- <dict-tag :options="roleObj" :value="scope.row.role_ids" /> -->
                                </template>
                            </el-table-column>
                            <el-table-column label="手机号码" align="center" key="mobile" prop="mobile"
                                v-if="columns[4].visible" width="120" />
                            <el-table-column label="邮箱" align="center" key="email" prop="email" width="120" />
                            <el-table-column label="余额" align="center" prop="balance" width="120">
                                <template #default="scope">
                                    <el-tag type="success" size="small" v-if="scope.row.balance">{{ scope.row.balance
                                        }}</el-tag>
                                </template>
                            </el-table-column>
                            <el-table-column label="开发者" prop="is_developer" align="center" width="90">
                                <template #default="scope">
                                    <dict-tag :options="enumFieldData.is_developer" :value="scope.row.is_developer" />
                                </template>
                            </el-table-column>
                            <el-table-column label="开发者状态" prop="developer_status" align="center" width="90">
                                <template #default="scope">
                                    <!-- <el-switch v-model="scope.row.developer_status" :active-value="1"
                                        :inactive-value="0" @change="handleStatusChange(scope.row)"></el-switch> -->
                                    <dict-tag :options="enumFieldData.developer_status"
                                        :value="scope.row.developer_status" />
                                </template>
                            </el-table-column>
                            <el-table-column label="会员状态" align="center" key="status" v-if="columns[5].visible">
                                <template #default="scope">
                                    <el-switch v-model="scope.row.status" :active-value="1" :inactive-value="0"
                                        @change="handleStatusChange(scope.row)"></el-switch>
                                </template>
                            </el-table-column>
                            <el-table-column label="创建时间" align="center" prop="create_time" v-if="columns[6].visible"
                                width="160">
                            </el-table-column>
                            <el-table-column label="操作" align="center" width="400" class-name="">
                                <template #default="scope">
                                    <!-- 未删除 -->
                                    <div v-if="!scope.row.delete_time">
                                        <el-button link size="small" type="success" @click="handleUpdate(scope.row)"
                                            v-hasPermi="['member:edit']">
                                            <icon-ep-edit class="icon" />修改</el-button>
                                        <el-button link size="small" type="info" @click="handleResetPwd(scope.row)"
                                            v-hasPermi="['member:resetPwd']"><icon-ep-key
                                                class="icon" />重置密码</el-button>
                                        <el-button link size="small" type="danger" @click="handleDelete(scope.row)"
                                            v-hasPermi="['member:delete']"><icon-ep-delete class="icon" />删除</el-button>
                                    </div>
                                    <!-- 回收站 -->
                                    <div class="" v-else>
                                        <el-button link size="small" type="info" @click="handleRestore(scope.row)"
                                            v-hasPermi="['system:role:recycle']" v-if="scope.row.role_id != 1">
                                            <icon-ep-refreshLeft class="icon" />恢复
                                        </el-button>
                                        <el-button link size="small" type="danger" @click="handleDeleteTrue(scope.row)"
                                            v-hasPermi="['system:role:recycle']" v-if="scope.row.role_id != 1">
                                            <icon-ep-delete class="icon" />彻底删除
                                        </el-button>
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>
                        <!-- 分页 -->
                        <pagination v-show="total > 0" :total="total" v-model:page="queryParams.pageNum"
                            v-model:limit="queryParams.pageSize" @pagination="getList" />
                    </el-col>
                </pane>
            </splitpanes>
        </el-row>

        <!-- 添加或修改会员配置对话框 -->
        <el-dialog :title="title" v-model="open" width="600px" append-to-body draggable>
            <el-form :model="form" :rules="rules" ref="userRef" label-width="90px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item v-if="form.id == undefined" label="会员名" prop="username">
                            <el-input v-model="form.username" placeholder="请输入会员名 只能是字母和数字" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item v-if="form.id == undefined" label="密码" prop="password">
                            <el-input v-model="form.password" placeholder="请输入会员密码" type="password" maxlength="20"
                                show-password />
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="会员角色" prop="role_ids">
                            <el-select v-model="form.role_ids" placeholder="请选择">
                                <el-option v-for="(value, key) in roleObj" :key="key" :label="value"
                                    :value="Number(key)"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="邮箱" prop="email">
                            <el-input v-model="form.email" placeholder="请输入邮箱" maxlength="50" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机" prop="mobile">
                            <el-input v-model="form.mobile" placeholder="请输入手机号码" maxlength="11" />
                        </el-form-item>
                    </el-col>

                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="会员昵称" prop="nickname">
                            <el-input v-model="form.nickname" placeholder="请输入会员昵称" maxlength="30" />
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="性别">
                            <el-select v-model="form.sex" placeholder="请选择">
                                <el-option v-for="dict in enumFieldData.sex" :key="dict.value" :label="dict.label"
                                    :value="dict.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="开发者" prop="is_developer">
                            <el-radio-group v-model="form.is_developer">
                                <el-radio v-for="dict in enumFieldData.is_developer" :key="Number(dict.value)"
                                    :value="Number(dict.value)">
                                    {{ dict.label }}
                                </el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开发者状态" prop="developer_status">
                            <el-radio-group v-model="form.developer_status">
                                <el-radio v-for="dict in enumFieldData.developer_status" :key="Number(dict.value)"
                                    :value="Number(dict.value)">
                                    {{ dict.label }}
                                </el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :span="24">
                        <el-form-item label="头像" prop="avatar">
                            <image-upload v-model="form.avatar" :limit="1" :action="uploadUrl"
                                :data="extraUploadData"></image-upload>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :span="12">
                        <el-form-item label="会员状态">
                            <el-radio-group v-model="form.status">
                                <el-radio v-for="dict in enumFieldData.status" :key="Number(dict.value)"
                                    :value="Number(dict.value)">
                                    {{ dict.label }}
                                </el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>

                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="备注">
                            <el-input v-model="form.remark" type="textarea" placeholder="请输入内容"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button type="primary" @click="submitForm">确 定</el-button>
                    <el-button @click="cancel">取 消</el-button>
                </div>
            </template>
        </el-dialog>

        <!-- 会员导入对话框 -->
        <el-dialog :title="upload.title" v-model="upload.open" width="400px" append-to-body>
            <el-upload ref="uploadRef" :limit="1" accept=".xlsx, .xls" :headers="upload.headers"
                :action="upload.url + '?updateSupport=' + upload.updateSupport" :disabled="upload.isUploading"
                :on-progress="handleFileUploadProgress" :on-success="handleFileSuccess" :auto-upload="false" drag>
                <!-- <el-icon class="el-icon--upload"><upload-filled /></el-icon> -->
                <el-icon class="el-icon--upload"><file-upload /></el-icon>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                <template #tip>
                    <div class="el-upload__tip text-center">
                        <div class="el-upload__tip">
                            <el-checkbox v-model="upload.updateSupport" />是否更新已经存在的会员数据
                        </div>
                        <span>仅允许导入xls、xlsx格式文件。</span>
                        <el-link type="primary" :underline="false" style="font-size: 12px; vertical-align: baseline"
                            @click="importTemplate">下载模板</el-link>
                    </div>
                </template>
            </el-upload>
            <template #footer>
                <div class="dialog-footer">
                    <el-button type="primary" @click="submitFileForm">确 定</el-button>
                    <el-button @click="upload.open = false">取 消</el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
// import { getToken } from "@/utils/auth"
import useMemberStore from '@/store/modules/user'
import useAppStore from '@/store/modules/app'
import { change, listMember, resetMemberPwd, delMember, updateMember, addMember, } from "@/api/member/member";
import { Splitpanes, Pane } from "splitpanes"
import "splitpanes/dist/splitpanes.css"
import { handleEnumField, clone, obj2tag, join_path } from "@/utils/kucoder"
import { pluginPath } from "@/api/kucoder"
import useUserStore from '@/store/modules/user';

defineOptions({
    name: 'KucoderSystemMember'
})

const userStore = useUserStore()
const router = useRouter()
const appStore = useAppStore()
const { proxy } = getCurrentInstance()

const userList = ref([])
const open = ref(false)
const loading = ref(true)
const showSearch = ref(true)
const ids = ref([])
const single = ref(true)
const multiple = ref(true)
const total = ref(0)
const title = ref("")
const dateRange = ref([])
const enabledDeptOptions = ref([])
const initPassword = ref(undefined)
const postOptions = ref([])

// 上传地址 不带后端域名
const uploadUrl = join_path(pluginPath, userStore.site_set.upload_path)
console.log('uploadUrl', uploadUrl)
// 上传额外携带的数据
const extraUploadData = ref({ upload_plugin: 'member' })

/*** 会员导入参数 */
const upload = reactive({
    // 是否显示弹出层（会员导入）
    open: false,
    // 弹出层标题（会员导入）
    title: "",
    // 是否禁用上传
    isUploading: false,
    // 是否更新已经存在的会员数据
    updateSupport: 0,
    // 设置上传的请求头部
    headers: { Authorization: "Bearer " + useMemberStore().token },
    // 上传的地址
    url: import.meta.env.VITE_APP_BASE_API + "/system/user/importData"
})
// 列显隐信息
const columns = ref([
    { label: `会员编号`, visible: true },
    { label: `会员名称`, visible: true },
    { label: `会员昵称`, visible: true },
    { label: `角色`, visible: true },
    { label: `手机号码`, visible: true },
    { label: `状态`, visible: true },
    { label: `创建时间`, visible: true },

])

const data = reactive({
    form: {},
    queryParams: {
        pageNum: 1,
        pageSize: 10,
        username: undefined,
        mobile: undefined,
        status: undefined,
        recycle: 0,
        is_developer: undefined, // 是否开发者
        role_ids: undefined, // 角色ID
    },
    rules: {
        username: [{ required: true, message: "会员名称不能为空", trigger: "blur" }, { min: 2, max: 20, message: "会员名称长度必须介于 2 和 20 之间", trigger: "blur" }],
        // nickname: [{ required: true, message: "会员昵称不能为空", trigger: "blur" }],
        password: [{ required: true, message: "会员密码不能为空", trigger: "blur" }, { min: 6, message: "会员密码长度必须大于等于6位", trigger: "blur" }, { pattern: /^[^<>"'|\\]+$/, message: "不能包含非法字符：< > \" ' \\\ |", trigger: "blur" }],
        email: [{ type: "email", message: "请输入正确的邮箱地址", trigger: ["blur", "change"] }],
        mobile: [{ pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "请输入正确的手机号码", trigger: "blur" }],
        role_ids: [{ required: true, message: "角色不能为空", trigger: "blur" }],
    }
})

const { queryParams, form, rules } = toRefs(data)

const enumFieldData = ref({})
const roleObj = ref({})
const roleObjTag = ref({})
/** 查询会员列表 */
function getList() {
    loading.value = true
    listMember(proxy.addDateRange(queryParams.value, dateRange.value, 'create_time')).then(({ res, msg, code }) => {
        loading.value = false
        userList.value = res.list.items
        enumFieldData.value = handleEnumField(res.enumFieldData || {})
        total.value = res.total
        roleObj.value = res.list.roles || {}
        roleObjTag.value = obj2tag(roleObj.value)
        console.log('roleObj.value', roleObj.value, roleObjTag.value)
    })
}

/** 回收站按钮操作 */
function handleRecycle() {
    queryParams.value.recycle = 1; // 设置查询回收站数据
    getList(); // 重新查询菜单列表
}
// 刷新
function refresh() {
    queryParams.value.pageNum = 1
    queryParams.value.recycle = 0 // 重置回收站查询
    getList()
}
/** 回收站恢复按钮操作 */
function handleRestore(row) {
    const ids = row.id || ids.value
    proxy.$modal.confirm('是否确认恢复会员编号为"' + ids + '"的数据项?').then(function () {
        return change({ id: ids, delete_restore: 1 })
    }).then(() => {
        getList()
        proxy.$modal.msgSuccess("恢复成功")
    }).catch(() => { })
}
/** 删除按钮操作 */
function handleDelete(row) {
    const ids = row.id || ids.value
    proxy.$modal.confirm('是否确认删除会员编号为"' + ids + '"的数据项？').then(function () {
        return delMember({ id: ids })
    }).then(() => {
        getList()
        proxy.$modal.msgSuccess("删除成功")
    }).catch(() => { })
}
/**回收站彻底删除按钮操作 */
function handleDeleteTrue(row) {
    const ids = row.id || ids.value
    proxy.$modal.confirm('是否确认彻底删除会员编号为"' + ids + '"的数据项?').then(function () {
        return delMember({ id: ids, isTrue: true })
    }).then(() => {
        getList()
        proxy.$modal.msgSuccess("彻底删除成功")
    }).catch(() => { })
}

/** 通过条件过滤节点  */
const filterNode = (value, data) => {
    if (!value) return true
    return data.label.indexOf(value) !== -1
}

/** 搜索按钮操作 */
function handleQuery() {
    queryParams.value.pageNum = 1
    getList()
}

/** 重置按钮操作 */
function resetQuery() {
    dateRange.value = []
    proxy.resetForm("queryRef")
    handleQuery()
}



/** 导出按钮操作 */
function handleExport() {
    proxy.download("system/user/export", {
        ...queryParams.value,
    }, `user_${new Date().getTime()}.xlsx`)
}

/** 会员状态修改  */
function handleStatusChange(row) {
    if (queryParams.value.recycle == 1) {
        proxy.$modal.msgWarning("回收站数据不能修改状态")
        row.status = Number(!row.status)
        return false;
    }
    let text = row.status === "0" ? "启用" : "停用"
    proxy.$modal.confirm('确认要"' + text + '""' + row.username + '"会员吗?').then(function () {
        return change({ id: row.id, status: row.status })
    }).then(() => {
        proxy.$modal.msgSuccess(text + "成功")
    }).catch(function () {
        row.status = row.status === "0" ? "1" : "0"
    })
}

/** 更多操作 */
function handleCommand(command, row) {
    switch (command) {
        case "handleResetPwd":
            handleResetPwd(row)
            break
        case "handleAuthRole":
            // handleAuthRole(row)
            break
        default:
            break
    }
}

/** 跳转角色分配 */
/* function handleAuthRole(row) {
  const id = row.id
  router.push("/system/user-auth/role/" + id)
} */

/** 重置密码按钮操作 */
function handleResetPwd(row) {
    ElMessageBox.prompt('请输入"' + row.username + '"的新密码', "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        closeOnClickModal: false,
        inputPattern: /^.{6,20}$/,
        inputErrorMessage: "会员密码长度必须介于 6 和 20 之间",
        inputValidator: (value) => {
            if (/<|>|"|'|\||\\/.test(value)) {
                return "不能包含非法字符：< > \" ' \\\ |"
            }
        },
    }).then(({ value }) => {
        resetMemberPwd(row.id, value).then(response => {
            proxy.$modal.msgSuccess("修改成功")
        })
    }).catch(() => { })
}

/** 选择条数  */
function handleSelectionChange(selection) {
    ids.value = selection.map(item => item.id)
    single.value = selection.length != 1
    multiple.value = !selection.length
}

/** 导入按钮操作 */
function handleImport() {
    upload.title = "会员导入"
    upload.open = true
}

/** 下载模板操作 */
function importTemplate() {
    proxy.download("system/user/importTemplate", {
    }, `user_template_${new Date().getTime()}.xlsx`)
}

/**文件上传中处理 */
const handleFileUploadProgress = (event, file, fileList) => {
    upload.isUploading = true
}

/** 文件上传成功处理 */
const handleFileSuccess = (response, file, fileList) => {
    upload.open = false
    upload.isUploading = false
    proxy.$refs["uploadRef"].handleRemove(file)
    proxy.$alert("<div style='overflow: auto;overflow-x: hidden;max-height: 70vh;padding: 10px 20px 0;'>" + response.msg + "</div>", "导入结果", { dangerouslyUseHTMLString: true })
    getList()
}

/** 提交上传文件 */
function submitFileForm() {
    proxy.$refs["uploadRef"].submit()
}

/** 重置操作表单 */
function reset() {
    form.value = {
        id: undefined,
        username: undefined,
        nickname: undefined,
        password: undefined,
        mobile: undefined,
        email: undefined,
        sex: undefined,
        status: 1,
        remark: undefined,
        postIds: [],
        role_ids: []
    }
    proxy.resetForm("userRef")
}

/** 取消按钮 */
function cancel() {
    open.value = false
    reset()
}

/** 新增按钮操作 */
function handleAdd() {
    reset()
    open.value = true
    title.value = "添加会员"
}

/** 修改按钮操作 */
function handleUpdate(row) {
    console.log('row', row, typeof row.status)
    form.value = clone(row)
    open.value = true
    title.value = "修改会员"
}

/** 提交按钮 */
function submitForm() {
    proxy.$refs["userRef"].validate(valid => {
        if (valid) {
            if (form.value.id != undefined) {
                updateMember(form.value).then(response => {
                    proxy.$modal.msgSuccess("修改成功")
                    open.value = false
                    getList()
                })
            } else {
                addMember(form.value).then(response => {
                    proxy.$modal.msgSuccess("新增成功")
                    open.value = false
                    getList()
                })
            }
        }
    })
}

// getDeptTree()
getList()
</script>