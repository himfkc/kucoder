<?php
declare(strict_types=1);

namespace plugin\member\app\admin\controller;

use plugin\member\app\admin\model\MemberRole;
use plugin\kucoder\app\kucoder\controller\AdminBase;
use support\Response;
use think\db\exception\DataNotFoundException;
use think\db\exception\DbException;
use think\db\exception\ModelNotFoundException;

class MemberController extends AdminBase
{
    protected string $modelClass = "\\plugin\\member\\app\\admin\\model\\Member";
    protected string|array $withoutField = 'password';
    protected array $withJoin = ['role'=>['role_id','role_name']];


    /**
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     * @throws DbException
     */
    protected function index_after(&$items): array
    {
        // $roles = MemberRole::field('role_id,role_name')->select()->toArray();
        $roles = MemberRole::where('status','=',1)->column('role_name', 'role_id');
        return [
            'items' => $items,
            'roles' => $roles,
        ];
    }

    protected function add_before(&$data):void
    {
        //用户密码处理
        if (isset($data['password']) && $data['password']) {
            if (strlen($data['password']) < 6) {
                $this->throw('密码长度不能小于6位');
            }
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        } else {
            unset($data['password']);
        }
    }

    public function profile()
    {

    }



    /**
     * 重置密码
     */
    public function resetPwd():Response
    {
        $id = $this->request->post('m_id');
        if (!$id) {
            return $this->error('参数错误');
        }
        $password = $this->request->post('password');
        if (!$password) {
            return $this->error('请输入密码');
        }
        if (strlen($password) < 6) {
            return $this->error('密码长度不能小于6位');
        }
        $password = password_hash($password, PASSWORD_DEFAULT);
        $this->model->where('m_id', $id)->update(['password' => $password]);
        return $this->success();
    }
}