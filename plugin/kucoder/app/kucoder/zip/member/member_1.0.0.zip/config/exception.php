<?php

return [
    '' => support\exception\Handler::class,
];
