<?php
declare(strict_types=1);

namespace plugin\member\app\admin\controller;

use plugin\kucoder\app\kucoder\controller\AdminBase;

class MemberRoleController extends AdminBase
{
    protected string $modelClass = "\\plugin\\member\\app\\admin\\model\\MemberRole";
}