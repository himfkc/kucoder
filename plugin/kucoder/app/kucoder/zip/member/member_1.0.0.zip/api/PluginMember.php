<?php
declare(strict_types=1);

namespace plugin\member\api;

/**
 * 插件对外提供的接口类
 */
class PluginMember
{

}